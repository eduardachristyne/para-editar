<?php 
$estilo = "<link rel='stylesheet' href='agenda/css/login.css'> ";
include_once 'header.php';
?>
        
<body class="fundologin">
    <div class="login-interprete">

    
        <h1>Login</h1>
        <form action="login.php" method="post">
            <input type="text" placeholder="Login" name="txtlogin">
            <br><br>
            <input type="password" placeholder="Senha" name="txtsenha">
            <br><br>
            <a href="interprete.php"><button type="submit" name="btenviar">Acessar</button></a>
        </form>


    <?php
    if (isset($_POST['btenviar'])):
        //1 - codigo de sanitizacao
        $login = filter_input(INPUT_POST,'txtlogin',FILTER_SANITIZE_SPECIAL_CHARS);//sanitiza login
        $senha =filter_input(INPUT_POST,'txtsenha',FILTER_SANITIZE_SPECIAL_CHARS);//sanitiza senha

        

        //2- codigo de validação        
        $erros = array(); //array de erros
        if(filter_input(INPUT_POST,'txtlogin',FILTER_VALIDATE_EMAIL)===false): 
            $erros[] = "Login inválido!";
        endif;
        
        if (empty($erros)):           
            //autenticação no banco de dados
            if(empty($login) or empty($senha)):
                $erros[] = "<li> O campo login/senha devem ser preenchidos </li>";
            else:
                require_once 'db_connect.php';
                
                //criptografando a senha
                $senha=md5($senha);
                
                $sql= "SELECT idinterprete,emailinterprete,senhainterprete,nomeinterprete FROM interprete WHERE emailinterprete= '$login' AND senhainterprete='$senha'";
                
                $resultado = mysqli_query($connect,$sql);
                //fechando a conexão depois de armazenar os dados
                mysqli_close($connect);
                
                //numeros de linhas do resultado da query maior que 0 ou Se houver algum registro na tabela
                if (mysqli_num_rows($resultado) > 0):
                    $dados=mysqli_fetch_array($resultado);                    
                    $_SESSION['usuario']= $dados['nomeinterprete'];
                    //comenado que redireciona para página 16home.php - deve criar essa página
                    header('Location: index.php');		
                
                else:
                    $erros[]="<li>Usuário e senha não conferem.</li>";
                    
                endif;


                
            endif;	   
        endif;	      


        if (!empty($erros)):
                       
            foreach($erros as $erro):
                echo "<li> $erro </li>";
            endforeach;
        endif;
    endif; 



    ?>
    </div>
</body>
</html>
