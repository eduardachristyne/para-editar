<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="agenda/css/marcacao.css">
  <script src="agenda/js/marcacao.js" defer></script>
  <title>Cadastrar horários</title>
  <script type="text/javascript" src="marcacao.js"></script>
</head>
<body="minhaFuncao()">
  <div class="conteudo">
    <div class="calendario">
      <header>
         <H2 id="mes">Julho</H2>
         <!-- <div style=" border: 1px solid black;"> -->
            <a class="btn-ant" id="btn_ant"><</a> 
            <a class="btn-pro" id="btn_prev">></a>
         <!-- </div> -->
      </header>
      <table>
        <thead>
          <tr>
            <td>Dom</td>
            <td>Seg</td>
            <td>Ter</td>
            <td>Qua</td>
            <td>Qui</td>
            <td>Sex</td>
            <td>Sab</td>
          </tr>
        </thead>
        <tbody id="dias">
          <tr>
            <td class="mes-anterior">1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr>
            <td>1</td>
            <td>2</td>
            <td class="dia-atual event">3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td class="event">4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td class="proximo-mes">7</td>
          </tr>
        </tbody>
      </table>
      <footer>
        <h2 id="ano">2023</h2>
      </footer>
    </div>
</div>
</body>
</html>
