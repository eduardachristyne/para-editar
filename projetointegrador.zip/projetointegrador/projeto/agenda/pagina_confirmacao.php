<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
    <link rel="stylesheet" href="css/pagina_confirmacao.css">
</head>
<body>
    <section class="centralizar">
    <div class="corfundo centralizar">
        <h1>Informe os dados do paciente</h1>
    </div class = "centralizar">
        <br><div class="coluna">
            <div CLASS="tamanho">
                <div>
                    <label for="nome">Nome completo</label>
                    <input type="text" id="nome"placeholder="Nome completo">
                    <br><br>
                </div>
            <div>
                <label for="data_nasc">Data de nascimento</label>
                <br><br>
                <input type="date" id="data_nasc" name="data">
                <br><br>
            </div>
                <label>Consultar com:</label><br>
			    <input type="radio" id="Cardiologista" value="Cardiologista" name="especialidade"><label for="Cardiologista" class="light">Cardiologista</label><br>
			    <input type="radio" id="Clínico Geral" value="Clínico Geral" name="especialidade"><label for="Clínico Geral" class="light">Clínico Geral</label><br>	
			    <input type="radio" id="Dermatologista" value="Dermatologista" name="especialidade"><label for="Dermatologista" class="light">Dermatologista</label><br>	
			    <input type="radio" id="Endocrinologista" value="Endocrinologista" name="especialidade"><label for="Endocrinologista" class="light">Endocrinologista</label><br>	
			    <input type="radio" id="Geriatra" name="especialidade"><label for="Geriatra" class="light">Geriatra</label><br>	
                <input type="radio" id="Gastroenterologista" value="Gastroenterologista" name="especialidade"><label for="Gastroenterologista" class="light">Gastroenterologista</label><br>
                <input type="radio" id="Infectologista" value="Infectologista" name="especialidade"><label for="Infectologista" class="light">Infectologista</label><br>
                <input type="radio" id="Médico do trabalho" value="Médico do trabalho" name="especialidade"><label for="Médico do trabalho" class="light">Médico do trabalho</label><br>
                <label for="nome">Outro:</label>
                <input type="text" id="nome"><br><br>
        </section>
        <div class="div1">
            <a href="resul.php"><button>SOLICITAR CONSULTA</button>
        </div>
</body>
</html>